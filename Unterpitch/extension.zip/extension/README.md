# Rehearsal Coach — Chrome extension (prototype)

Slide-aware rehearsal feedback for German and English talks. Speech-to-text (Whisper) and analysis run
locally in the browser; audio never leaves the device.

## Install (developer mode)
1. Open `chrome://extensions`
2. Turn on **Developer mode** (top right)
3. Click **Load unpacked** and choose this `extension` folder
4. Pin "Rehearsal Coach" from the puzzle-piece menu

## Use
- Click the toolbar icon → the coach opens in its own tab.
- **On a Google Slides tab**, clicking the icon imports that deck automatically (uses your Google session to export a PPTX).
- **PowerPoint Online:** File → Download a copy, then upload the .pptx.
- Rehearse live (mic, ← → to change slides), upload an audio file, or run the built-in demo.

## Offline
All code (transformers.js, ONNX runtime WASM, JSZip) is bundled in `vendor/`. The speech model
(~40–250 MB) is downloaded from Hugging Face on first use and cached; after that everything works offline.
Google Slides import needs a connection, PPTX upload does not.

## Files
- `manifest.json`: MV3, cross-origin isolated (multi-threaded WASM), `wasm-unsafe-eval` CSP
- `background.js`: opens the app tab, exports Google Slides decks
- `app.html` / `app.js`: UI, PPTX parsing, recording
- `analysis.js`: coverage, alignment, delivery stats, questions (shared with `../prototype`)
- `worker.js`: local Whisper transcription
